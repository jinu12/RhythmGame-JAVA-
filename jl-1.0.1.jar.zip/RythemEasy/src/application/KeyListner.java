package application;

import java.awt.event.KeyAdapter;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;


public class KeyListner extends KeyAdapter {
	
	
	public void KeyPressed(KeyEvent e) {
		if(e.getCode() == KeyCode.A ) {
			
		}
		else if(e.getCode() == KeyCode.S ) {
			
		}
		else if(e.getCode() == KeyCode.D ) {
			
		}
		else if(e.getCode() == KeyCode.F ) {
			
		}
		else if(e.getCode() == KeyCode.G ) {
			
		}
		else if(e.getCode() == KeyCode.H ) {
			
		}
		
	}

	public void OnKeyReleased(KeyEvent e) {
		if(e.getCode() == KeyCode.A ) {
			
		}
		else if(e.getCode() == KeyCode.S ) {
			
		}
		else if(e.getCode() == KeyCode.D ) {
			
		}
		else if(e.getCode() == KeyCode.F ) {
			
		}
		else if(e.getCode() == KeyCode.G ) {
			
		}
		else if(e.getCode() == KeyCode.H ) {
			
		}
	}
}
